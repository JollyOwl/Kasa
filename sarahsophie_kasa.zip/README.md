# About the Project 

Open Classroom project by sarah-Sophie Thouabtia

# Stack

React + Vite 
Tailwind CSS 
json file for data

# Github repo
https://github.com/JollyOwl/kasa.git

# Live site
https://jollyowl.github.io/kasa/

