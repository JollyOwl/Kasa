# About the Project 

Open Classroom project by sarah-Sophie Thouabtia

# Stack

React + Vite 
Tailwind CSS 
json file for data

# URL 
https://jollyowl.github.io/kasa/